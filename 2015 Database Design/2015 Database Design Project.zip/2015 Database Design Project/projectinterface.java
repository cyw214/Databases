import java.sql.*;
import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class projectinterface {
  
  public static String DBusername = "cyw214";
  public static String DBpassword = "1234!@#$";
  
  
  
  public static void main(String[] args)  throws SQLException, IOException, java.lang.ClassNotFoundException {
    try {
      
    
      
     interfaces inter = new interfaces();
     inter.mainMenu();
   
    } catch(Exception e){e.printStackTrace();}
  }
  
}



 