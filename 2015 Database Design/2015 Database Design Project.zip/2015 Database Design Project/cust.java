import java.sql.*;
import java.io.*;

public class cust {
  
  private String cust_id, card_num, exp_date;
  private String first_name, last_name, card_type;
  private String address, city, state, zip, status, email;
  boolean online;
  
  
  //default cust constructor
  public cust()
  {
    this.cust_id = "000000";
    this.first_name = "Unknown";
    this.last_name = "Unknown";
    this.card_num = "null";
    this.exp_date = "null";
    this.card_type = "null";
    address = "Unknown";
    city = "Unknown";
    state = "Unknown";
    zip = "Unknown";
    status = "Not";
    email = "Unknown";
    online = false;
    
  }
  
  //cust constructor
  public cust(String cust_id, String first_name, String last_name, String card_num, String exp_date, String card_type)
  {
    this.cust_id = cust_id;
    this.first_name = first_name;
    this.last_name = last_name;
    this.card_num = card_num;
    this.exp_date = exp_date;
    this.card_type = card_type;
    address = "Unknown";
    city = "Unknown";
    state = "Unknown";
    zip = "Unknown";
    status = "Not";
    email = "Unknown";
    online = false;
  }
  
  public String getcust_id()
  {
    return cust_id;
  }
  
  public String getfirst_name()
  {
    return first_name;
  }
  
  public String getlast_name()
  {
    return last_name;
  }
  
  public String getcard_num()
  {
    return card_num;
  }
  
  public String getexp_date()
  {
    return exp_date;
  }
  
  public String getcard_type()
  {
    return card_type;
  }
  
  public String getaddress()
  {
    return address;
  }
  public String getcity()
  {
    return city;
  }
  public String getstate()
  {
    return state;
  }
  public String getzip()
  {
    return zip;
  }
  public String getstatus()
  {
  return status;
  }
  public String getemail()
  {
    return email;
  }
  public boolean getonline()
  {
     return online;
  }
  public void setfreq_cust(String paddress, String pcity, String pstate, String pzip, String pstatus, String pemail)
  {
    address = paddress;
    city = pcity;
    state = pstate;
    zip = pzip;
    status = pstatus;
    email = pemail;
      
  }
  
  public void setonline()
  {
     online = true;
  }
  
  public void printcust()
  {
    System.out.println("PROFILE:");
    System.out.println("--------"); 
    System.out.format("%-20s %-20s %-22s", "|First Name", "|Last Name", "|User Name","|Status");
    System.out.println();
        for(int i = 0; i < 63; i++) System.out.print("-");  
    System.out.println();
    System.out.format("%-20s %-20s %-22s", "|" + first_name, "|" + last_name, "|" + status + " Member");
    System.out.println();
    System.out.println("\nADDRESS:");
    System.out.println("--------");
    System.out.format("%-20s %-20s %-22s", "|City", "|State", "|ZIP");
    System.out.println();
       for(int i = 0; i < 63; i++) System.out.print("-");  
    System.out.println();
    System.out.format("%-20s %-20s %-22s", "|" + city, "|" + state, "|" + zip);
    System.out.println();
    System.out.println();
    System.out.print("|Mailing Address: ");
    System.out.print(address);
    System.out.println();
    System.out.println("----------------- ");
    System.out.println();
    System.out.print("|EMAIL:");
    System.out.print( email);
    System.out.println();
    System.out.println("----------------- ");
    System.out.println();
    System.out.println("|CREDIT CARD INFORMATION");
    System.out.println("------------------------");
    String star = "";
    for(int i = 0; i < card_num.length() - 4; i++)
      star = star + "*";   
    String hiddencardnum = card_num.substring((card_num.length()-4), card_num.length());
    System.out.format("%-20s %-20s %-22s", "|Card #", "|Exp. Date", "|Card Type");
    System.out.println();
       for(int i = 0; i < 63; i++) System.out.print("-");  
    System.out.println();
    System.out.format("%-20s %-20s %-22s", "|" + star + hiddencardnum, "|" + exp_date.substring(0,2) + "/"+exp_date.substring(2,exp_date.length()), "|" + card_type);
    
  }
  
  
  
}