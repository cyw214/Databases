import java.sql.*;
import java.io.*;
import java.util.*;

public class DBinterface {
  
 static String DBusername = projectinterface.DBusername;
 static String DBpassword = projectinterface.DBpassword;
  
  private String username, password, query;
  private ResultSet result;
  private ResultSetMetaData rsmd;
  private Connection con;
  private Statement s;
  
  
  //retains password and username as well as a ResultSetMetaDataobject
  public DBinterface()
  {
    this.username = username;
    this.password = password;
    this.con=null;
    this.s = null;
    this.result = null;
    this.rsmd =null;
    
  }
  
  // Opens connection to database
  public void open_con()  throws SQLException, IOException, java.lang.ClassNotFoundException
  {   try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
    con=DriverManager.getConnection("jdbc:oracle:thin:@edgar1.cse.lehigh.edu:1521:cse241",DBusername,
                                    DBpassword);
  } catch(Exception e){e.printStackTrace();}
  }
  
  // Closes Connection to database
  public void close_con() throws SQLException, IOException, java.lang.ClassNotFoundException
  { try{
    con.close(); 
    }catch(Exception e){e.printStackTrace();}
  }
  
  //query database
  public void querydatabase(String query)  throws SQLException, IOException, java.lang.ClassNotFoundException {
    try 
    {
      s = con.createStatement();
      result = s.executeQuery(query);
      rsmd = result.getMetaData();
      
    } catch(SQLException sqle){System.out.println("Attempt failed " + sqle) ;}
  }
  
  //update database
  public void updatedatabase(String update) throws SQLException, IOException, java.lang.ClassNotFoundException {
    try 
    {
        s = con.createStatement();
        s.executeUpdate(update);
      }catch(SQLException sqle){System.out.println("Attempt Unsuccessful " + sqle); }
    }
  
  
  // returns an array list of ArrayLists where each element of the ArrayList
  // is an ArrayList represnting a row from the result.
  public List<List<String>> resultToArrayList() throws SQLException, IOException, java.lang.ClassNotFoundException {
    try 
    {
      int numcols = result.getMetaData().getColumnCount();
      List<List<String>> ALresult = new ArrayList<List<String>>();
     
      ArrayList<String> firstrow = new ArrayList<String>(numcols); // new list per row
      int i = 1;
      while (i <= numcols) // don't skip the last column, use <=
        firstrow.add(rsmd.getColumnName(i++));
      ALresult.add(firstrow); // add it to the result
       
      
      while (result.next()) {
          ArrayList<String> row = new ArrayList<String>(numcols); // new list per row
          int h = 1;
        while (h <= numcols) {  // don't skip the last column, use <=
          row.add(result.getString(h++));
       }
         ALresult.add(row); // add it to the result
       }
       return ALresult;
    } catch(Exception e){e.printStackTrace();}
    return null;
  }
  
  public List<String> resultcolumnToArrayList() throws SQLException, IOException, java.lang.ClassNotFoundException {
    try 
    {
      ArrayList<String> column = new ArrayList<String>();
      int i = 1;
      while(result.next())
      column.add(result.getString(i));
      return column;
    
   } catch(Exception e){e.printStackTrace();}
    return null;
  }
    
  // function prints the entire relation called into a metadata member by the query database function.
  public void printfullrelation() throws SQLException, IOException, java.lang.ClassNotFoundException {
    
    try{
      
      Class.forName("oracle.jdbc.driver.OracleDriver");
      con=DriverManager.getConnection("jdbc:oracle:thin:@edgar1.cse.lehigh.edu:1521:cse241",DBusername, DBpassword);
      String head = "";  
      int[] width = new int[rsmd.getColumnCount()];
      for (int i = 1; i <= rsmd.getColumnCount(); i++) {
        width[i-1] = rsmd.getPrecision(i);
        head += rsmd.getColumnName(i);
        for (int j = rsmd.getColumnName(i).length(); j <= Math.max(width[i-1],rsmd.getColumnName(i).length()); j++) {
          head += " ";
        }
      }
      System.out.println(head);
      if (!result.next()) System.out.println ("Empty result.");
      else {
        do {
          for (int i = 1; i <= rsmd.getColumnCount(); i++) {
            System.out.print (result.getString(i));
            for (int j = result.getString(i) == null ? 4 
                   : result.getString(i).length(); 
                 j <= Math.max(width[i-1],rsmd.getColumnName(i).length()); j++) {
                   System.out.print (" ");
                 } 
          }
          System.out.println();
        } while (result.next());
      }
      con.close();
    } catch(Exception e){e.printStackTrace();}
  }
  
  
//end of class
}

