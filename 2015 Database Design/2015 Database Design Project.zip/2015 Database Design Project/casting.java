
public class casting{

  public static void main(String args[]){
     A a = new A(); 
     B b = new B(); 
     A ab = new B();I
     
     ab.display(b); 
     
     ab.display(a); 
     b.display(ab); 
     b.display(b);
  
  
  }
  
  public static class A
  {
    A(){ System.out.println("A is called");}
    
    public void display(A a){
    System.out.println("In A.display(A)");
    }
       
  }
  
  public static class B extends A
  {
    
    B(){System.out.println("B is called");}
    
    public void display(A a){
      System.out.println("In B.display(A)");
    }
    
    public void display(B b){
      System.out.println("In B.display(B)");
    }
    
  
  }

}