import java.sql.*;
import java.io.*;
import java.util.*;

public class cust_product {
  
  private String upc, brand_name, store_id, sale_price, quantity, product_name, weight, p_type, description, product_type;
  private cust customer;
  
    public cust_product(String upc, String brand_name, String product_name, String product_type, String weight, String description, String store_id, String sale_price, String quantity){
      this.upc = upc;
      this.brand_name = brand_name;
      this.product_name = product_name;
      this.product_type = product_type;
      this.weight = weight;
      this.description = description;
      this.store_id = store_id;
      this.sale_price = sale_price;
      this.quantity = quantity;
      this.customer = new cust("000000", "Anon", "Anon", "null", "null", "null");
    }
  
    public String getupc(){
      return upc;
    }
    public String getstore_id(){
      return store_id;
    }
    public String getbrand_name(){
      return brand_name;
    }
    public String getsale_price(){
      return sale_price;
    }
    public String getquantity(){
      return quantity;
    }
    public String getproduct_name(){
      return product_name;
    }
    public String getweight(){
      return weight;
    }
    public String getdescription(){
      return description;
    }
    
    public String getcust_id()
    {
       String c_id = customer.getcust_id();
       return c_id;
    }
    
    public void setcust(cust c)
    {
        customer = c;
    }
    public void addquantity(String q){
      int temp = Integer.valueOf(quantity) + Integer.valueOf(q);    
      quantity = String.valueOf(temp);
    }
    
    

      
      

        
}