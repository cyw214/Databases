import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Date;
import java.text.*;

public class storemanagerinterface {
  
  public static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
  public static String managermenuSelect = null;
  //public static String customerID = null;
  public static String s = null;
  
  
  //ArrayList<cust_product> cust_products = new ArrayList<cust_product>();
  DBinterface dataconnection = new DBinterface();
  
  ///////////////////////////////////////////
  ///// choose Store Manager location ///////
  ///////////////////////////////////////////
  public void mainMenu() {
    try{
      while(true){
        List<List<String>> storelist;
        List<String> store_ids;
        
        dataconnection.open_con();
        dataconnection.querydatabase("select store_id, Address, city, state from store");
        storelist = dataconnection.resultToArrayList();
        dataconnection.querydatabase("select store_id state from store");
        store_ids = dataconnection.resultcolumnToArrayList();
        dataconnection.close_con();  
        commandLine("clear");
        for(int i = 0; i < storelist.size(); i++){
          System.out.format("%-8s %-25s %-15s %-15s",storelist.get(i).get(0), storelist.get(i).get(1), storelist.get(i).get(2), storelist.get(i).get(3));
          System.out.print("\n");
        } 
        
        System.out.print("Enter the Store_id for the location you manage: ");
        boolean forward = true;
        Scanner input = new Scanner(System.in);
        String store_id = input.next();
        if(store_id.equalsIgnoreCase("back"))
        {
          break;
        }
        do{
          for(int i = 0; i < store_ids.size(); i++)
          {
            if(store_ids.get(i).equals(store_id)){
              forward = false;
            }
          }
          if(forward == true){
            System.out.print("Store does not exist, please re-enter a store id from the list: ");
            store_id = input.next();
          }
        }while(forward == true);
        
        storeManagermenu(store_id);
        
      }
      
    } catch (IOException e) { System.out.println("exception happened: ");e.printStackTrace();System.exit(-1);
    } catch (Exception e) { e.printStackTrace();}   
  }
  
  /////////////////////////////////////
  ////// Store Manager Options ///////
  ///////////////////////////////////
  public void storeManagermenu(String store_id)
  { try{
    commandLine("clear");
    System.out.println("[Type <back> to enter a different store]");
    System.out.print("STORE MANAGER MENU\n");
    System.out.println("Please select an option: \na) Customer\nb) Inventory\n");
    
    while (true) {
      System.out.print("Enter Selection: ");
      managermenuSelect = br.readLine();
      if (managermenuSelect.length() < 1) {
        System.out.println("Invalid input, please type in a, or b ");
      } else {
        if (managermenuSelect.equalsIgnoreCase("a")) {
          System.out.println("Customer");
          storeCustomermenu(store_id);
          break;
          // put in method for a
          // break;
        } else if (managermenuSelect.equalsIgnoreCase("b")) {
          System.out.println("Inventory");
          storeInventorymenu(store_id);
          break;
        } else if (managermenuSelect.equalsIgnoreCase("c")) {
          System.out.println("Performance");
          // put in method for c
          break;
        } else if (managermenuSelect.equalsIgnoreCase("back")){
          break;
        }else {
          System.out.println("Invalid input, please type in a, b, or c");
          
          // break;
          
        }
      }
    }     
  } catch (IOException e) {System.out.println("exception happened: ");e.printStackTrace();System.exit(-1);
  } catch (Exception e) {e.printStackTrace();}   
  }
  
  /////////////////////////////////////
  ///// Inventory  Menu     ///////////
  /////////////////////////////////////
  public void storeInventorymenu(String store_id)
  {   
    try{
      String inventorymenuSelect = "";
      while (true) {
        commandLine("clear");
        System.out.println("[Type <back> to enter a different store]");
        System.out.print("STORE MANAGER INVENTORY MENU\n");
        System.out.println("Please select an option: \na) Reorder \nb) Add Products\n");
        System.out.print("Enter Selection: ");
        inventorymenuSelect = br.readLine();
        if(inventorymenuSelect.equals("a"))
        {
          commandLine("clear");
          System.out.println("[Type <back> to return to Shopping menu.]");
          System.out.println("Select A Department From the Following to view:  ");
          System.out.println("a) Camp\nb) Climb\nc) Cycle\nd) Hike\ne) Kayak");
          System.out.print("Enter Selection: ");
          BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
          String choice = br1.readLine();
          boolean exitloop = false;
          while(true){
            if (choice.length() < 1 || (choice.length() > 1 && !(choice.equalsIgnoreCase("back")))){
              System.out.print("Invalid input, please type in a, b, c, d, or back: "); 
              choice = br1.readLine();
            } else{
              if(choice.equalsIgnoreCase("a")){
                choice = "Camp";
              }
              else if(choice.equalsIgnoreCase("b")){
                choice = "Climb";
              }  
              else if(choice.equalsIgnoreCase("c")){
                choice = "Cycle";
              }
              else if(choice.equalsIgnoreCase("d")){
                choice = "Hike";
              }
              else if(choice.equalsIgnoreCase("e")){
                choice = "Kayak";
              }
              else if(choice.equalsIgnoreCase("back")){
                //storeCustomerMenu(store_id, cust_products, customer );
                break;
              }else{ System.out.print("Invalid input, please type in a, b, c, d, or back: "); choice = br.readLine();}
              if( choice.equals("Camp") || choice.equals("Climb") || choice.equals("Cycle") || choice.equals("Hike") || choice.equals("Kayak"))
              { 
                do{
                  List<String> product_types;
                  List<List<String>> products;
                  String dochoice = choice;
                  commandLine("clear");
                  System.out.println("[Type <back> to return to shopping menu.]");
                  dataconnection.open_con();
                  dataconnection.querydatabase("select p_type from store_inv natural join productandp_type natural join " + choice + " where store_id =" + store_id +"group by p_type order by p_type asc");
                  product_types = dataconnection.resultcolumnToArrayList();
                  dataconnection.close_con();
                  
                  dataconnection.open_con(); 
                  dataconnection.querydatabase("Select upc, brand_name, product_name, sale_price, p_type from  " + choice + " natural join makes natural join brand natural join store_inv where store_id = "+store_id+" order by p_type asc");
                  products = dataconnection.resultToArrayList();
                  dataconnection.close_con();
                  System.out.println();
                  int selectcount = 0;
                  for(int j = 0; j < product_types.size(); j++){
                    System.out.println(product_types.get(j) + ":");
                    System.out.format("%-12s %-20s %-30s %-10s","|selection #","|" + products.get(0).get(1), "|" + products.get(0).get(2), "|" + products.get(0).get(3));
                    System.out.println();
                    for(int i = 0; i < 76; i ++)
                      System.out.print("-");
                    System.out.println();
                    for(int i = 0; i < products.size(); i++){
                      
                      if((products.get(i).get(4)).equals(product_types.get(j))){
                        selectcount++;
                        String strselectcount = String.format("%-1d",selectcount);
                        System.out.format("%-12s %-20s %-30s %-10s", strselectcount + ".)" ,products.get(i).get(1), products.get(i).get(2), "$" + products.get(i).get(3));
                        System.out.print("\n");
                      }    
                    }
                    System.out.println();
                  }
                  
                  boolean forward = false;
                  System.out.print("Enter the product selection # to view or purchase: ");
                  choice = br1.readLine();
                  if (choice.equalsIgnoreCase("back"))
                    break;
                  
                  String intstring = "";
                  String stringint = "";
                  do{
                    
                    for(int i = 0; i < products.size(); i++)
                    {
                      intstring = String.valueOf(i);
                      stringint = String.valueOf(choice);
                      if(stringint.equals(intstring) && i != 0){
                        forward = true;
                      }
                    }
                    if(forward == false){
                      System.out.println("Invalid Entry");
                      System.out.print("Enter the product selection # to view or purchase: ");
                      choice = br1.readLine();
                      if (choice.equalsIgnoreCase("back"))
                        break;
                    }
                  }while(forward == false);
                  
                  if(choice.equalsIgnoreCase("back"))
                    break;
                  
                  int choiceint = 0;
                  if(!choice.equalsIgnoreCase("back")){
                    choiceint = Integer.valueOf(choice);
                    productSelection(dochoice, products.get(choiceint).get(0), store_id);
                  }
                  if (!choice.equalsIgnoreCase("back"))
                    choice = dochoice;
                }while(!choice.equalsIgnoreCase("back")); 
              }
            }
          }
        }else if(inventorymenuSelect.equals("b"))
        {   commandLine("clear");
          System.out.println("[Type <back> to return to Shopping menu.]");
          System.out.println("Select A Department From the Following to view:  ");
          System.out.println("a) Camp\nb) Climb\nc) Cycle\nd) Hike\ne) Kayak");
          System.out.print("Enter Selection: ");
          BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
          String choice = br1.readLine();
          boolean exitloop = false;
          while(true){
            if (choice.length() < 1 || (choice.length() > 1 && !(choice.equalsIgnoreCase("back")))){
              System.out.print("Invalid input, please type in a, b, c, d, or back: "); 
              choice = br1.readLine();
            } else{
              if(choice.equalsIgnoreCase("a")){
                choice = "Camp";
              }
              else if(choice.equalsIgnoreCase("b")){
                choice = "Climb";
              }  
              else if(choice.equalsIgnoreCase("c")){
                choice = "Cycle";
              }
              else if(choice.equalsIgnoreCase("d")){
                choice = "Hike";
              }
              else if(choice.equalsIgnoreCase("e")){
                choice = "Kayak";
              }
              else if(choice.equalsIgnoreCase("back")){
                //storeCustomerMenu(store_id, cust_products, customer );
                break;
              }else{ System.out.print("Invalid input, please type in a, b, c, d, or back: "); choice = br.readLine();}
              if( choice.equals("Camp") || choice.equals("Climb") || choice.equals("Cycle") || choice.equals("Hike") || choice.equals("Kayak"))
              { 
                do{
                  List<String> product_types;
                  List<List<String>> products;
                  String dochoice = choice;
                  commandLine("clear");
                  System.out.println("[Type <back> to return to shopping menu.]");
                  System.out.println("[The Following Products are Not in the storeInventory]");
                  dataconnection.open_con();
                  dataconnection.querydatabase("select p_type from (Select upc, brand_name, product_name, p_type from  " + choice + " natural join makes natural join brand natural join vendor_inv " 
                                                 + " minus Select upc, brand_name, product_name, p_type from  " + choice + " natural join makes natural join brand natural join store_inv where store_id = "+store_id+") "
                                                 + " group by p_type order by p_type");
                  product_types = dataconnection.resultcolumnToArrayList();
                  dataconnection.close_con();
                  
                  dataconnection.open_con(); 
                  dataconnection.querydatabase("(Select upc, brand_name, product_name, p_type from  " + choice + " natural join makes natural join brand natural join vendor_inv "
                                                 + " minus Select upc, brand_name, product_name, p_type from  " + choice + " natural join makes natural join brand natural join store_inv where store_id = "+store_id+") "
                                                 + " order by p_type asc");
                  products = dataconnection.resultToArrayList();
                  dataconnection.close_con();
                  
                  System.out.println();
                  int selectcount = 0;
                  for(int j = 0; j < product_types.size(); j++){
                    System.out.println(product_types.get(j) + ":");
                    System.out.format("%-12s %-20s %-30s","|selection #","|" + products.get(0).get(1), "|" + products.get(0).get(2));
                    System.out.println();
                    
                    for(int i = 0; i < 76; i ++)
                      System.out.print("-");
                    System.out.println();
                    for(int i = 0; i < products.size(); i++){
                      
                      if((products.get(i).get(3)).equals(product_types.get(j))){
                        selectcount++;
                        String strselectcount = String.format("%-1d",selectcount);
                        System.out.format("%-12s %-20s %-30s", strselectcount + ".)" ,products.get(i).get(1), products.get(i).get(2));
                        System.out.print("\n");
                      }    
                    }
                    System.out.println();
                  }
                  
                  boolean forward = false;
                  System.out.print("Enter the product selection # to view or purchase: ");
                  choice = br1.readLine();
                  if (choice.equalsIgnoreCase("back"))
                    break;
                  
                  String intstring = "";
                  String stringint = "";
                  do{
                    
                    for(int i = 0; i < products.size(); i++)
                    {
                      intstring = String.valueOf(i);
                      stringint = String.valueOf(choice);
                      if(stringint.equals(intstring) && i != 0){
                        forward = true;
                      }
                    }
                    if(forward == false){
                      System.out.println("Invalid Entry");
                      System.out.print("Enter the product selection # to view or purchase: ");
                      choice = br1.readLine();
                      if (choice.equalsIgnoreCase("back"))
                        break;
                    }
                  }while(forward == false);
                  
                  if(choice.equalsIgnoreCase("back"))
                    break;
                  
                  int choiceint = 0;
                  if(!choice.equalsIgnoreCase("back")){
                    choiceint = Integer.valueOf(choice);
                    productSelection(dochoice, products.get(choiceint).get(0), store_id);
                  }
                  if (!choice.equalsIgnoreCase("back"))
                    choice = dochoice;
                }while(!choice.equalsIgnoreCase("back")); 
              }
            }
          }
          
        }else if (inventorymenuSelect.equals("back")){
          break;
        }else{
          System.out.println("Invalid input, please type in a, b, or back");
        }
        
        
        
      }
    } catch (IOException e) {System.out.println("exception happened: ");e.printStackTrace();System.exit(-1);
    } catch (Exception e) {e.printStackTrace();}  
  }
  //////////////////////////////////////
  //////PRODUCT SELECTION FOR REORDER //
  /////////////////////////////////////
  public void productSelection(String dept_type, String upc, String store_id) {
    try {
      commandLine("clear");
      BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
      
      List<List<String>> selecteditem;
      dataconnection.open_con();
      dataconnection.querydatabase("Select * from "+ dept_type +" natural join makes natural join brand natural join vendor_inv where upc = " + upc);
      selecteditem = dataconnection.resultToArrayList();
      dataconnection.close_con();
      
      String brand_name = selecteditem.get(1).get(1);
      String product_name = selecteditem.get(1).get(2);
      String product_type = selecteditem.get(1).get(3);
      String weight = selecteditem.get(1).get(4);
      String description = selecteditem.get(1).get(5);
      String vendor_id = selecteditem.get(1).get(6);
      String sale_price = selecteditem.get(1).get(7);
      String quantity = "0";
      
      
      System.out.format("%-6s %-10s %-30s %-8s %-10s","Vend_Id","|Brand","|Product Name", "|Weight","|Vendor Price");
      System.out.print("\n");
      for(int i = 0; i < 75; i++)
      {
        System.out.print("-");
      }
      System.out.println();
      System.out.format("%-6s %-10s %-30s %-8s %-10s",vendor_id, brand_name,product_name,weight,"$"+sale_price);
      System.out.println();
      System.out.println("Description: " + "");
      System.out.println("-----------");
      
      List<String> paragraph = new ArrayList<String>();
      Pattern substring = Pattern.compile(".{1,50}(?:\\s|$)", Pattern.DOTALL);
      Matcher m = substring.matcher(description);
      while (m.find()) {
        paragraph.add(m.group());
      }
      
      for (int i = 0; i < paragraph.size(); i++) {
        System.out.println(paragraph.get(i));
      }
      System.out.println();
      
      String choice;
      System.out.print("Would You like to order more of this product (y|n)? ");
      choice = br1.readLine();
      if(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"))
        do{       
        System.out.print("Please enter (y|n) ");
        choice = br1.readLine();
      }while(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"));
      if(choice.equalsIgnoreCase("y")){      
        
        System.out.print("Enter how many you would like to purchase: ");
        quantity = br1.readLine();
        
        while(true){     
          if(!checkint(quantity)){
            System.out.println("Please a number greater than zero: ");
            quantity = br1.readLine();}
          else if(Integer.valueOf(quantity) <= 0){
            System.out.println("Please a number greater than zero: ");
            quantity = br1.readLine();}
          
          else
            break;
        }
        
        if(choice.equalsIgnoreCase("y"))
        {
          
          DateFormat df = new SimpleDateFormat("ddMMyyyy");
          Date today = Calendar.getInstance().getTime(); 
          String trandate = df.format(today);
          trandate = "to_date('" + trandate + "','DDMMYYYY')";
          dataconnection.open_con();
          dataconnection.updatedatabase("insert into vend_tran values( "+vendor_id+", "+store_id+", "+upc+", "+ trandate+", "+sale_price+", "+quantity+")");
          dataconnection.close_con();
          System.out.println(quantity +" " + product_name + "(s) have been shipped to your store. Press Enter to Return to Inventory");
          br.readLine();
        }    
      }    
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  /////////////////////////////////////
  /////Store Customer Menu ///////////
  /////////////////////////////////////
  public void storeCustomermenu(String store_id){
    try{
      while (true) {
        commandLine("clear");
        System.out.println("[Type <back> to enter a different store]");
        System.out.print("STORE MANAGER CUSTOMER MENU\n");
        System.out.println("Please select an option: \na) Customer Transactions \nb) Customer Profiles\n");
        System.out.print("Enter Selection: ");
        managermenuSelect = br.readLine();
        if(managermenuSelect.equalsIgnoreCase("back"))
          break;
        if (managermenuSelect.length() > 1 || managermenuSelect.length() < 1) {
          System.out.println("Invalid input, please type in a or b");
        } else {
          ///Customer Transactions
          if (managermenuSelect.equalsIgnoreCase("a")) {
            //// view customer transactions by date range:
            boolean display = false;
            String startdate = "";
            String enddate = "";
            while(true)
            {  
              List<List<String>> translist;
              commandLine("clear");
              System.out.println("[Type <back> to return to customer menu]");
              System.out.println("[View transactions between two dates by typing a start and end date]");
              System.out.println("Customer Transactions:");
              System.out.println("----------------------");
              
              if(display == true){
                dataconnection.open_con();
                dataconnection.querydatabase("Select date_trans as Tran_Date, cust_id as customer_id, upc, amt_paid, quantity " 
                                               + " from  store_cust natural join cust_trans natural join productandp_type where date_trans BETWEEN TO_DATE ('"+ startdate +  " ', 'dd/mm/yyyy') "
                                               + " AND TO_DATE ('"+ enddate +"', 'dd/mm/yyyy') and store_id = " + store_id
                                               +  " order by date_trans asc") ;
                translist = dataconnection.resultToArrayList();
                dataconnection.close_con();
                System.out.format("%-21s| %-12s| %-14s| %-9s| %-9s|","Tran_Date[yyyy-mm-dd]", translist.get(0).get(1), translist.get(0).get(2), translist.get(0).get(3), translist.get(0).get(4));
                System.out.println();
                System.out.println("--------------------------------------------------------------------------");
                double totalsales = 0;
                for(int i = 1; i < translist.size(); i++){
                  System.out.format("%-21s| %-12s| %-14s| %-9s| %-9s|",translist.get(i).get(0).substring(0,10), translist.get(i).get(1), translist.get(i).get(2), translist.get(i).get(3), translist.get(i).get(4));
                  System.out.print("\n");
                  totalsales = totalsales + Double.valueOf(translist.get(i).get(3))*Double.valueOf(translist.get(i).get(4));  
                } 
                System.out.println("Total Sales: " + totalsales);
              }
              do{
                System.out.print("Enter Start Date (dd/mm/yyyy): ");
                startdate = br.readLine();
                if(startdate.equalsIgnoreCase("back"))
                  break;              
              }while(!validate(startdate));
              if(startdate.equalsIgnoreCase("back"))
                break;
              
              do{             
                System.out.print("Enter End Date (dd/mm/yyyy): ");
                enddate = br.readLine();
                if(startdate.equalsIgnoreCase("back"))
                  break;       
              }while(!validateend(startdate, enddate));
              if(startdate.equalsIgnoreCase("back"))
                break;
              
              display = true;   
            }
            // put in method for a
            // break;
          } 
          ///////////////////////////Customer Profiles
          else if (managermenuSelect.equalsIgnoreCase("b")) {
            System.out.println("Customer Profiles");
            boolean display = false;
            String letter = "";
            String custid = "";
            String customersearch = "";
            
            while(true)
            {  
              List<List<String>> translist;
              commandLine("clear");
              System.out.println("[Type <back> to return to customer menu]");
              System.out.println("[Select from A-Z to to sort by store customers with Corresponding first letter in name]");
              System.out.println("Customer Profiles: ");
              System.out.println("----------------------");
              
              if(display == true){
                dataconnection.open_con();
                dataconnection.querydatabase("Select distinct cust_id, last_name, first_name " 
                                               + " from (Select * from cust_trans natural join store_cust order by cust_id)"
                                               + " where store_id = 108 and cust_id != 0 and last_name like '"+letter+"%'"
                                               +  " order by last_name, first_name");
                translist = dataconnection.resultToArrayList();
                dataconnection.close_con();
                System.out.format("%-21s| %-12s| %-14s|", translist.get(0).get(0), translist.get(0).get(1), translist.get(0).get(2));
                System.out.println();
                System.out.println("--------------------------------------------------------------------------");
                for(int i = 1; i < translist.size(); i++){
                  System.out.format("%-21s| %-12s| %-14s|",translist.get(i).get(0), translist.get(i).get(1), translist.get(i).get(2));
                  System.out.print("\n");  
                }
                while(true)
                {
                  
                  System.out.print("would you like to view one of the listed profiles (y|n)? ");
                  custid = br.readLine();
                  
                  if(custid.equalsIgnoreCase("y")){
                    System.out.print("Enter Customer Id: ");
                    custid = br.readLine();
                    customersearch = "select * from store_cust where cust_id = " + custid + " "; 
                    if(checknoresult(customersearch)){
                      
                      System.out.println("Invalid Input");
                    }
                    else if(!checknoresult(customersearch)){
                      
                      customerprofile(custid);
                      commandLine("clear");
                      System.out.println("[Type <back> to return to customer menu]");
                      System.out.println("[Select from A-Z to to sort by store customers with Corresponding first letter in last name]");
                      System.out.println("Customer Profiles: ");
                      System.out.println("----------------------");
                      System.out.format("%-21s| %-12s| %-14s|", translist.get(0).get(0), translist.get(0).get(1), translist.get(0).get(2));
                      System.out.println();
                      System.out.println("--------------------------------------------------------------------------");
                      for(int i = 1; i < translist.size(); i++){
                        System.out.format("%-21s| %-12s| %-14s|",translist.get(i).get(0), translist.get(i).get(1), translist.get(i).get(2));
                        System.out.print("\n");  
                      }
                      break;
                    }
                  }else if(custid.equalsIgnoreCase("n")){
                    break;
                  }else{
                    System.out.println("Please Enter (y|n)");
                  }
                }
              }
              do{
                System.out.print("Enter Letter To Sort By: ");
                letter = br.readLine();
                if(letter.equalsIgnoreCase("back"))
                  break;              
              }while(!validletter(letter));
              if(letter.equalsIgnoreCase("back"))
                break;
              letter = letter.toUpperCase();
              
              display = true;   
            }
            //deleted break
          } else {
            System.out.println("Invalid input, please type in a, b, or back");    
          }
        }
      } 
    } catch (IOException e) {System.out.println("exception happened: ");e.printStackTrace();System.exit(-1);
    } catch (Exception e) {e.printStackTrace();}  
  }
  
  /////////////////////////////////////
  ///// Customer Profile    ///////////
  /////////////////////////////////////
  public void customerprofile(String custid) throws SQLException, IOException, java.lang.ClassNotFoundException
  {
    try{
      String searchfreq = "select * from freq_cust where cust_id = " + custid;
      String searchstorecust = "select * from store_cust where cust_id = " + custid;
      List<List<String>> custinfo;
      
      if(!checknoresult(searchfreq))
      {
        dataconnection.open_con();
        dataconnection.querydatabase(searchfreq);
        custinfo = dataconnection.resultToArrayList();
        dataconnection.printfullrelation();
        dataconnection.close_con();
        //readline
        br.readLine();
        cust freqcust = new cust(custinfo.get(1).get(0), custinfo.get(1).get(1), custinfo.get(1).get(2), custinfo.get(1).get(3), custinfo.get(1).get(4), custinfo.get(1).get(5));
        freqcust.setfreq_cust(custinfo.get(1).get(6), custinfo.get(1).get(7), custinfo.get(1).get(8), custinfo.get(1).get(9), custinfo.get(1).get(10), custinfo.get(1).get(11));
        freqcust.printcust();
        System.out.println();
        System.out.print("Press Enter to return to search.");
        br.readLine();
      }else if(!checknoresult(searchstorecust)){
        dataconnection.open_con();
        dataconnection.querydatabase(searchstorecust);
        custinfo = dataconnection.resultToArrayList();
        dataconnection.close_con();
        // readline
        br.readLine();
        cust storecust = new cust(custinfo.get(1).get(0), custinfo.get(1).get(1), custinfo.get(1).get(2), custinfo.get(1).get(3), custinfo.get(1).get(4), custinfo.get(1).get(5));
        storecust.printcust();
        System.out.println();
        System.out.print("Press Enter to return to search.");
        br.readLine();
      }
      else{System.out.println("Customer Does Not exist, press Enter to return to search"); br.readLine();}
      
      
    } catch (IOException e) {System.out.println("exception happened: ");e.printStackTrace();System.exit(-1);
    } catch(SQLException sqle){System.out.println("Attempt failed ");}   
  }
  
  
  public boolean validletter(String letter)
  {
    if(letter.equalsIgnoreCase("a")) return true; else if(letter.equalsIgnoreCase("b")) return true; else if(letter.equalsIgnoreCase("c")) return true;
    else if(letter.equalsIgnoreCase("d")) return true; else if(letter.equalsIgnoreCase("e")) return true; else if(letter.equalsIgnoreCase("f")) return true; 
    else if(letter.equalsIgnoreCase("g")) return true; else if(letter.equalsIgnoreCase("h")) return true; else if(letter.equalsIgnoreCase("i")) return true;
    else if(letter.equalsIgnoreCase("j")) return true; else if(letter.equalsIgnoreCase("k")) return true; else if(letter.equalsIgnoreCase("l")) return true;
    else if(letter.equalsIgnoreCase("m")) return true; else if(letter.equalsIgnoreCase("n")) return true; else if(letter.equalsIgnoreCase("o")) return true;
    else if(letter.equalsIgnoreCase("p")) return true; else if(letter.equalsIgnoreCase("q")) return true; else if(letter.equalsIgnoreCase("r")) return true;
    else if(letter.equalsIgnoreCase("s")) return true; else if(letter.equalsIgnoreCase("t")) return true; else if(letter.equalsIgnoreCase("u")) return true;
    else if(letter.equalsIgnoreCase("v")) return true; else if(letter.equalsIgnoreCase("w")) return true; else if(letter.equalsIgnoreCase("x")) return true;
    else if(letter.equalsIgnoreCase("y")) return true; else if(letter.equalsIgnoreCase("z")) return true; 
    else {System.out.println("Invalid input, please enter a letter of the alphabet"); return false;}
  }
  
  public boolean validateend(String startdate, String enddate)
  { try{
    
    if(Integer.valueOf(startdate.substring(6,10)) > Integer.valueOf(enddate.substring(6,10))){
      System.out.println("Start date must come before the end date.");
      return false;
    }
    
    else if(startdate.substring(6,10).equals(enddate.substring(6,10)) && (Integer.valueOf(startdate.substring(3,5)) > Integer.valueOf(enddate.substring(3,5)))){
      System.out.println("Start date must come before the end date.");
      return false;
    }
    
    else if(startdate.substring(6,10).equals(enddate.substring(6,10)) && startdate.substring(3,5).equals(enddate.substring(3,5))  && (Integer.valueOf(startdate.substring(0,2)) > Integer.valueOf(enddate.substring(0,2)))){
      System.out.println("Start date must come before the end date.");
      return false;
    }else if(validate(enddate) == false){
      return false;
    }
    else
      return true;
  }catch(Exception e){System.out.println("whoa! Enter Some reasonable values in the proper format please."); return false;}
  
  }
  
  public boolean validate(String D)
  {  
    
    try{
      
      String day = D.substring(0,2);
      String month = D.substring(3,5);
      String year = D.substring(6,10);
      String slash1 = D.substring(2,3);
      String slash2 = D.substring(5,6);
      
      if(!checkint(D) && (Integer.valueOf(year) < 1990 || Integer.valueOf(year) > 2015))
      {System.out.println("Year must be between 1990 and 2015"); return false;}   
      if(!slash1.equals("/") || !slash2.equals("/"))
      {System.out.println("Syntax Error '/' must be included between day and month and month and year"); return false;}
      if(!checkint(D) && (Integer.valueOf(month) > 12 || Integer.valueOf(month) <= 0))
      {System.out.println("Enter a value betwee 1 and 12 for the month"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 1 && Integer.valueOf(day) > 31)
      {System.out.println("There are only 31 days in january"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 2 && Integer.valueOf(day) > 28)
      {System.out.println("There are only 28 days in febuary"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 3 && Integer.valueOf(day) > 31)
      {System.out.println("There are only 31 days in march"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 4 && Integer.valueOf(day) > 30)
      {System.out.println("There are only 30 days in april"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 5 && Integer.valueOf(day) > 31)
      {System.out.println("There are only 31 days in may"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 6 && Integer.valueOf(day) > 30)
      {System.out.println("There are only 30 days in june"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 7 && Integer.valueOf(day) > 31)
      {System.out.println("There are only 31 days in july"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 8 && Integer.valueOf(day) > 31)
      {System.out.println("There are only 31 days in august"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 9 && Integer.valueOf(day) > 30)
      {System.out.println("There are only 30 days in september"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 10 && Integer.valueOf(day) > 31)
      {System.out.println("There are only 31 days in october"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 11 && Integer.valueOf(day) > 30)
      {System.out.println("There are only 30 days in november"); return false;}
      if(!checkint(D) && Integer.valueOf(month) == 12 && Integer.valueOf(day) > 31)
      {System.out.println("There are only 31 days in december"); return false;}
      if (!checkint(D) && Integer.valueOf(day) < 0)
      {System.out.println("Day must be greater than 0"); return false;}
      if (!checkint(D) && Integer.valueOf(day) < 10 && !D.substring(0,1).equals("0"))
      {System.out.println("days with a value less than 10 must be preceded with a 0"); return false;}
      if (!checkint(D) && Integer.valueOf(month) < 10 && !D.substring(3,4).equals("0"))
      {System.out.println("months with a value less than 10 must be preceded with a 0"); return false;}
      return true;
    }catch(Exception e){System.out.println("whoa! Enter Some reasonable values in the proper format please."); return false;}
    
  }
  
  public static void commandLine(String command) {
    
    try {
      
      Process p = Runtime.getRuntime().exec(command);
      BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
      BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
      while ((s = input.readLine()) != null) {
        System.out.println(s);
      }
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }   
  }
  
  //returns true if number format is int or double and false otherwise
  public static boolean checkint(String s) {
    try { 
      Integer.parseInt(s);
      Double.parseDouble(s);
    } catch(NumberFormatException e) { 
      return false; 
    } 
    return true;
  }
  
  // returns true if query does not return a result and false otherwhise.
  public  boolean checknoresult(String s)throws SQLException, IOException, java.lang.ClassNotFoundException {
    try 
    {
      List<List<String>> att;       
      dataconnection.open_con();
      dataconnection.querydatabase(s);
      att = dataconnection.resultToArrayList();
      dataconnection.close_con();
      
      try{
        
        att.get(1).get(0);
        
      }catch(IndexOutOfBoundsException e){
        return true;
        
      }
    } catch(SQLException sqle){System.out.println("Attempt failed ");}           
    return false;        
  }
  
  public String Capstring(String word)
  {
    
    word = word.toLowerCase();
    String Capletter = word.substring(0,1).toUpperCase();
    return word = Capletter + word.substring(1,word.length());
    
  }
  
  public static String uniqueid()throws SQLException, IOException, java.lang.ClassNotFoundException{
    boolean notunique = true;
    boolean unique = true;
    String id = "";
    
    while(notunique){
      Random integer1 = new Random(); 
      int int1;
      Random integer2 = new Random();
      int int2;
      Random integer3 = new Random();
      int int3;
      Random integer4 = new Random();
      int int4;
      Random integer5 = new Random();
      int int5;
      Random integer6 = new Random();
      int int6;
      
      
      int1 = (integer1.nextInt(9) + 0 );
      int2 = (integer2.nextInt(9) + 0);
      int3 = (integer3.nextInt(9) + 0);
      int4 = (integer4.nextInt(9) + 0);
      int5 = (integer5.nextInt(9) + 0);
      int6 = (integer6.nextInt(9) + 0);
      id = int1 + "" + int2 + "" + int3 + "" + int4 + "" + int5 + "" + int6;
      try{    
        DBinterface connection = new DBinterface();
        
        List<String> DBids = new ArrayList<String>();
        
        
        connection.open_con();
        connection.querydatabase("select cust_id from store_cust");
        DBids = connection.resultcolumnToArrayList();
        connection.close_con();
        int i = 0;
        while(i > DBids.size()){
          if(Integer.valueOf(DBids.get(i)) == Integer.valueOf(id)){
            unique = false;
          }
          
        }
        if(unique)
          break;
      } catch(SQLException sqle){System.out.println("Attempt failed " + sqle) ;}
      
      
    } // end of while
    return id;
  }
}