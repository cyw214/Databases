import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Date;
import java.text.*;

public class interfaces {
  
  public static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
  public static String menuSelect = null;
  public static String customerID = null;
  public static String s = null;
  
  
  ArrayList<cust_product> cust_products = new ArrayList<cust_product>();
  DBinterface dataconnection = new DBinterface();
  
  ///////////////////////////////////////////////////
  //// Main menu starting point for all interfaces.///
  ///////////////////////////////////////////////////
  public void mainMenu() {
    String userName, password = null;
    
    try {

      
      while (true) {
              commandLine("clear");
      System.out.print("MAIN MENU\n");
      System.out.println("Please select an interface: \na) Customer\nb) Manager \nc) Exit");
        System.out.print("Enter Selection: ");
        menuSelect = br.readLine();
        if (menuSelect.length() > 1 || menuSelect.length() < 1) {
          System.out.println("Invalid input, please type in a, b, or c");
        } else {
          if (menuSelect.equalsIgnoreCase("a")) {
            System.out.println("You chose A");
            customerMenu();
            break;
            // put in method for a
            // break;
          } else if (menuSelect.equalsIgnoreCase("b")) {
            
            storemanagerinterface store = new storemanagerinterface();
            store.mainMenu();

          } else if (menuSelect.equalsIgnoreCase("c")) {
            System.out.println("Exiting");
            System.exit(0);
           
          }else {
            System.out.println("Invalid input, please type in a, b, or c");
            
            // break;
            
          }
        }
      }     
    } catch (IOException e) {
      System.out.println("exception happened: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }   
  }
  
  public void customerMenu() {
    try {
      while (true) {
        cust_products.clear();
        commandLine("clear");
        System.out.println("[Type <back> to return to main menu]");
        System.out.println("Would you prefer to shop at a physical location or online?");
        System.out.println("a) Store\nb) Online (membership required)");
        System.out.print("Enter Selection: ");
        menuSelect = br.readLine();
        if (menuSelect.length() < 1 || (menuSelect.length() > 1 && !(menuSelect.equalsIgnoreCase("back")))) {
          System.out.println("Invalid input, please type in a, b, or back");
        } else {
          if (menuSelect.equalsIgnoreCase("a")) {
            
            List<List<String>> storelist;
            List<String> store_ids;
            DBinterface dataconnection = new DBinterface();
            dataconnection.open_con();
            dataconnection.querydatabase("select store_id, Address, city, state from store where store_id != 111");
            storelist = dataconnection.resultToArrayList();
            dataconnection.querydatabase("select store_id state from store where store_id != 111");
            store_ids = dataconnection.resultcolumnToArrayList();
            dataconnection.close_con();  
            commandLine("clear");
            for(int i = 0; i < storelist.size(); i++){
              System.out.format("%-8s %-25s %-15s %-15s",storelist.get(i).get(0), storelist.get(i).get(1), storelist.get(i).get(2), storelist.get(i).get(3));
              System.out.print("\n");
            } 
            
            System.out.print("Enter the Store_id for the location where you wish to shop: ");
            boolean forward = true;
            Scanner input = new Scanner(System.in);
            String store_id = input.next();
            
            do{
              
              for(int i = 0; i < store_ids.size(); i++)
              {
                if(store_ids.get(i).equals(store_id)){
                  forward = false;
                }
              }
              if(forward == true){
                System.out.print("Store does not exist, please re-enter a store id from the list: ");
                store_id = input.next();
              }
            }while(forward == true);
            
            // ACCESS TO
            // PHYSICAL STORE
            cust anoncust = new cust();
            storeCustomerMenu(store_id, cust_products, anoncust);
            
            break;
          } else if (menuSelect.equalsIgnoreCase("b")) {
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                        
            commandLine("clear");
            BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in));
            
            String choice;
            // 1st while statement
            while(true){
              commandLine("clear");
              System.out.println("[Type <back> at any time to return to previous menu]");
              System.out.print("Online Login:\na) Login \nb) Sign up \nEnter selection: ");
              choice = br2.readLine();
              if(!choice.equalsIgnoreCase("a") && !choice.equalsIgnoreCase("b") && !choice.equalsIgnoreCase("back"))
                do{       
                System.out.print("Please enter a, b or back:  ");
                choice = br2.readLine();
              }while(!choice.equalsIgnoreCase("a") && !choice.equalsIgnoreCase("b") && !choice.equalsIgnoreCase("back"));
              
              
              if(choice.equalsIgnoreCase("back"))
              {  customerMenu(); 
                break;
              }
              else if (choice.equalsIgnoreCase("a")){
                while(true)
                { String username;
                  String password;
                  
                  commandLine("clear");
                  System.out.println("[User Authentication]");
                  System.out.print("Online Login:\na) Login \nb) Signup \nEnter Username (case sensitve): ");
                  username = br2.readLine();
                  if(choice.equalsIgnoreCase("back"))
                    break; // break login
                  List<String> foundusername;
                  dataconnection.open_con();
                  dataconnection.querydatabase("select username from freq_cust where username = '" + username + "'");
                  foundusername = dataconnection.resultcolumnToArrayList();
                  dataconnection.close_con();
                  if(foundusername.isEmpty()){
                    String back;
                    System.out.print("User Name not found. Press Enter to retry, back to exit online login. ");
                    back = br2.readLine();
                    if(back.equalsIgnoreCase("back"))
                      break;
                  }
                  else if(!foundusername.get(0).equals(username)){
                    String back;
                    System.out.print("User Name not found. Press Enter to retry, back to exit online login. ");
                    back = br2.readLine();
                    if(back.equalsIgnoreCase("back"))
                      break;
                    
                  }
                  else{
                    commandLine("clear");
                    System.out.println("[Password Authentication]");
                    System.out.print("Online Login:\na) Login \nb) Signup \nEnter Password (case sensitve): ");
                    password = br2.readLine();
                    if(choice.equalsIgnoreCase("back"))
                      break; // break login
                    List<String> foundpass;
                    dataconnection.open_con();
                    dataconnection.querydatabase("select pass from freq_cust where pass = '" + password + "' and username = '" + username + "'");
                    foundpass = dataconnection.resultcolumnToArrayList();
                    dataconnection.close_con();
                    if(foundpass.isEmpty()){
                      String back;
                      System.out.print("User Name not found. Press Enter to retry, back to exit online login. E");
                      back = br2.readLine();
                      if(back.equalsIgnoreCase("back"))
                        break;
                    }
                    else if(!foundpass.get(0).equals(password)){
                      String passfailed;
                      System.out.print("Password not found. Press Enter to retry, back to exit online login. ");
                      passfailed = br2.readLine();
                      if(passfailed.equalsIgnoreCase("back"))
                        break;
                    }
                    
                    String store_id = "111";
                    List<List<String>> custinfo;
                    dataconnection.open_con();
                    dataconnection.querydatabase("select * from freq_cust where pass = '" + password + "' and username = '" + username + "'");
                    custinfo = dataconnection.resultToArrayList();
                    dataconnection.close_con();
                    
                    cust onlinecust = new cust(custinfo.get(1).get(0), custinfo.get(1).get(1), custinfo.get(1).get(2), custinfo.get(1).get(3), custinfo.get(1).get(4), custinfo.get(1).get(5));
                    onlinecust.setfreq_cust(custinfo.get(1).get(6), custinfo.get(1).get(7), custinfo.get(1).get(8), custinfo.get(1).get(9), custinfo.get(1).get(10), custinfo.get(1).get(11));
                    onlinecust.setonline();
                    onlineCustomerMenu(store_id, onlinecust);                   
                    break;
                  }// end username entry password inside if then statements
                  break;
                  
                }//end password verification loop
                
              }
              else if (choice.equalsIgnoreCase("b")){
                signup(true);
                
                
              }
            }//end of outside while statement
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            
            break; //break customer menu
            
          } else if (menuSelect.equalsIgnoreCase("back")) {
            System.out.println("You chose back");
            mainMenu(); // goes back to main menu
            break;
          }else {
            System.out.println("Invalid input, please type in a, b, or back");
            
          }
        }
      }
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }  
  }
  
  // accepts boolean to differentiate between shoppers who are frequent or not.
  public cust signup(boolean freq)
  {
    try{
      commandLine("clear");
      String first_name, last_name, card_num, exp_date, card_type;
      cust new_cust =  new cust();
      
      while(true){
        
        System.out.println("[Type <back> at any time to return to store menu]");
        System.out.println();
        System.out.println("Enter the Follwing");
        System.out.println();
        
        System.out.print("First Name: ");
        first_name = br.readLine();
        first_name = Capstring(first_name);
        if(first_name.equalsIgnoreCase("back"))
        {customerMenu(); break;};
        
        System.out.print("Enter Last Name: ");
        last_name = br.readLine();
        last_name = Capstring(last_name);
        if(last_name.equalsIgnoreCase("back"))
        {customerMenu(); break;};
        
        do{
          System.out.print("Enter Card Number: ");
          card_num = br.readLine();
          if(last_name.equalsIgnoreCase("back"))
          {customerMenu(); break;};
          
          if(!checkint(card_num) || (card_num.length() < 6 && card_num.length() > 8))
            System.out.println(" Invalid: Must enter 6 to 8 consecutive integers for Card Number");
        }while(!checkint(card_num) || (card_num.length() < 6 || card_num.length() > 8));
        if(last_name.equalsIgnoreCase("back"))
        {customerMenu(); break;};
        
        String exp_month;
        String exp_year;
        
          do{
            System.out.print("Enter Card Month of expiration (mm): ");
            exp_month = br.readLine();
            if(exp_month.equalsIgnoreCase("back"))
            {customerMenu(); break;};
            
            if(!checkint(exp_month) || (Integer.valueOf(exp_month) < 0 || Integer.valueOf(exp_month) > 12) ||  exp_month.length() > 2)
            {
              System.out.println("Must Enter integers for expiration month between 1 and 12");
            }
          }while(!checkint (exp_month) || (Integer.valueOf(exp_month) < 0 || Integer.valueOf(exp_month) > 12 )||  exp_month.length() > 2);
          
          if(last_name.equalsIgnoreCase("back"))
          {customerMenu(); break;};

        if(exp_month.equalsIgnoreCase("back"))
        {customerMenu(); break;};
        if(Integer.valueOf(exp_month) < 10)
          exp_month = "0" + String.valueOf(Integer.valueOf(exp_month));
        
        do{    
          do{
            System.out.print("Enter Card year of expiration (yy): ");
            exp_year = br.readLine();
            if(last_name.equalsIgnoreCase("back"))
            {customerMenu(); break;};
            if(!checkint(exp_year))
            {
              System.out.println("Must enter two digit integers for expiration month ex: 1 for january");
            }
          }while(!checkint(exp_year));
          if(Integer.valueOf(exp_year) < 15 || exp_year.length() > 2)
          {
            System.out.println("Must Enter two digit integer greater than or equal to 15");
          }
          
          if(last_name.equalsIgnoreCase("back"))
          {customerMenu(); break;};
        }while(Integer.valueOf(exp_year) < 15 || exp_year.length() > 2);
        
        exp_date = exp_month + exp_year;
        
        if(last_name.equalsIgnoreCase("back"))
        {customerMenu(); break;};
        do{
          
          System.out.println("Choose a Card Type: ");
          System.out.print("\na) Chase\nb) Visa\nc) Citi\nd) Discover\ne) Master Card\nf) Capitol One \ng) American Express\n");
          System.out.print("Enter Selection: ");
          card_type = br.readLine();
          if(last_name.equalsIgnoreCase("back"))
          {customerMenu(); break;};
        }while(!card_type.equalsIgnoreCase("a") && !card_type.equalsIgnoreCase("b") && !card_type.equalsIgnoreCase("c") && !card_type.equalsIgnoreCase("d") && !card_type.equalsIgnoreCase("e") && !card_type.equalsIgnoreCase("f") && !card_type.equalsIgnoreCase("g"));
        
        if(last_name.equalsIgnoreCase("back"))
        {customerMenu(); break;};
        switch(card_type.charAt(0))
        {
          case 'a': card_type = "Chase"; break;
          case 'b': card_type = "Visa"; break;
          case 'c': card_type = "Citi"; break;
          case 'd': card_type = "Discover"; break;
          case 'e': card_type = "Master Card"; break;
          case 'f': card_type = "Capitol One"; break;
          case 'g': card_type = "American Express"; break;
          
        }
        String id = uniqueid();
        cust newcust = new cust(id, first_name, last_name, card_num, exp_date, card_type);
        String query  = "select * from freq_cust where first_name = '" + first_name +"' and last_name= '" + last_name + "' and card_num = '" + card_num + "' and exp_date = '" + exp_date + "' and card_type = '" + card_type +"'";      
        if(checknoresult(query)){
          dataconnection.open_con();
          dataconnection.updatedatabase("insert into store_cust values ("+ id + ", '" + first_name + "', '" + last_name + "', '" + card_num + "', " + exp_date + ", '" + card_type +"')");
          dataconnection.close_con();

          if(freq == false)
            return newcust;
        }else if (!checknoresult(query) && newcust.getonline() == false){return newcust;}
          if(checknoresult(query) && freq == true){
          String address, city, state, zip, status, email;
          
          
          System.out.print("Address: ");
          address = br.readLine();
          if(address.equalsIgnoreCase("back"))
          {customerMenu(); break;};
          
          System.out.print("City: ");
          city = br.readLine();
          if(city.equalsIgnoreCase("back"))
          {customerMenu(); break;};
          
          System.out.print("State: ");
          state = br.readLine();
          if(state.equalsIgnoreCase("back"))
          {customerMenu(); break;};
          
          do{
            System.out.print("Zip: ");
            zip = br.readLine();
            if(zip.equalsIgnoreCase("back"))
            {customerMenu(); break;};
            if(!checkint(zip))
              System.out.println("Not a valid zip code, zip must be composed of integers.");
          }while(!checkint(zip));
          
          if(zip.equalsIgnoreCase("back"))
          {customerMenu(); break;};
          
          email = "";
          boolean at = true;
          while(at){
            System.out.print("email: ");
            email = br.readLine();
            if(email.equalsIgnoreCase("back"))
            {customerMenu(); break;};
            
            char atsymbol = '@';
            for(int i = 0; i < email.length(); i++)
            {
              if(atsymbol == email.charAt(i))
                at = false;      
            }
            if(at)
            {System.out.println("@ must be in the email address");}
            else{  break;}
            
          }
          
          String un, pw;
          System.out.print("User Name: ");
          un = br.readLine();
          if(un.equalsIgnoreCase("back"))
          {customerMenu(); break;};
          
          System.out.print("Password: ");
          pw = br.readLine();
          if(pw.equalsIgnoreCase("back"))
          {customerMenu(); break;};
          
          status = "Silver";
          newcust.setfreq_cust(address, city, state, zip, status, email);
          dataconnection.open_con();
          dataconnection.updatedatabase("insert into freq_cust values ("+ id + ", '" + first_name + "', '" + last_name + "', " + card_num + ", " + exp_date + ", '" + card_type +"', '" + address + "', '" + city + "', '" + state + "', " + zip + ", '" + status + "', '" + email + "', '" +  pw + "', '" + un + "')");
          dataconnection.close_con();
          return newcust;
        }
        break;
            
        // end of inside while loop
      }// end of outside while loop
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }  
    cust anoncust = new cust();
    return anoncust;
  }
  
  //////////////////////////////////////////////////////
  // This is the online submenu from the customer menu //
  //////////////////////////////////////////////////////
  public void onlineCustomerMenu(String store_id, cust onlinecust) {
    try {
      while (true) {
        
        
        // log them into their profile
        // check if id exists 
        // if not, prompt them again
        
        commandLine("clear");
        System.out.println("[Type <back> to return to customer menu]");
        System.out.println("View ");
        System.out.println("a) Profile\nb) Shop\nc) Shopping Cart");
        System.out.print("Enter Selection: ");
        menuSelect = br.readLine();
        if (menuSelect.length() < 1 || (menuSelect.length() > 1 && !(menuSelect.equalsIgnoreCase("back")))) {
          System.out.println("Invalid input, please type in a, b, c, or back");
        } else {
          if (menuSelect.equalsIgnoreCase("a")) {
            
            while(true){
              commandLine("clear");
              System.out.println("[Type <back> to return to Online menu]");
              onlinecust.printcust();
              System.out.print("Enter Selection: ");
              String back = br.readLine();
              if(back.equalsIgnoreCase("back")){
                onlineCustomerMenu(store_id, onlinecust);
                break;
                
              }
            }
          } else if (menuSelect.equalsIgnoreCase("b")) {
           storeCustomerMenu(store_id, cust_products, onlinecust);
            break;
          } else if (menuSelect.equalsIgnoreCase("c")) {
            System.out.println("You chose C"); // you can delete this 
            // put in method for c
            // put in Shopping Cart stuff
            break;
          } else if (menuSelect.equalsIgnoreCase("back")) {
            System.out.println("You chose back");
            customerMenu(); // goes back to customer menu
            break;
          }else {
            System.out.println("Invalid input, please type in a, b, c, or back");
          }
        }
      }
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }
    
  }
  ////////////////////////////////////////////////////////////////
  // This is the physical store submenu from the customer menu ///
  ////////////////////////////////////////////////////////////////
  public void storeCustomerMenu(String store_id, ArrayList<cust_product> cust_products, cust customer ) {
    try {
      while (true) {
        
        commandLine("clear");
        System.out.println("[Type <back> to return to store menu.]");
        System.out.println("Shopping Menu:");
        System.out.println("a) Select Items\nb) Shopping Cart\nc) Check Out");
        if(!menuSelect.equals("a") || !menuSelect.equals("b") || !menuSelect.equals("c")){
          System.out.print("Enter Selection: ");
          menuSelect = br.readLine();
        }
        if (menuSelect.length() < 1 || (menuSelect.length() > 1 && !(menuSelect.equalsIgnoreCase("back")))) {
          System.out.println("Invalid input, please type in a, b, c or back");
        } else {
          if (menuSelect.equalsIgnoreCase("a")) {
            commandLine("clear");
            System.out.println("[Type <back> to return to Shopping menu.]");
            System.out.println("Select A Department From the Following to view:  ");
            System.out.println("a) Camp\nb) Climb\nc) Cycle\nd) Hike\ne) Kayak");
            System.out.print("Enter Selection: ");
            BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
            String choice = br1.readLine();
            boolean exitloop = false;
            
            while(true){
              if (choice.length() < 1 || (choice.length() > 1 && !(choice.equalsIgnoreCase("back")))){
                System.out.print("Invalid input, please type in a, b, c, d, or back: "); 
                choice = br1.readLine();
              } else{
                if(choice.equalsIgnoreCase("a")){
                  choice = "Camp";
                }
                else if(choice.equalsIgnoreCase("b")){
                  choice = "Climb";
                }  
                else if(choice.equalsIgnoreCase("c")){
                  choice = "Cycle";
                }
                else if(choice.equalsIgnoreCase("d")){
                  choice = "Hike";
                }
                else if(choice.equalsIgnoreCase("e")){
                  choice = "Kayak";
                }
                else if(choice.equalsIgnoreCase("back")){
                  storeCustomerMenu(store_id, cust_products, customer );
                  break;
                }else{ System.out.print("Invalid input, please type in a, b, c, d, or back: "); choice = br.readLine();}
                if( choice.equals("Camp") || choice.equals("Climb") || choice.equals("Cycle") || choice.equals("Hike") || choice.equals("Kayak"))
                { 
                  do{
                    List<String> product_types;
                    List<List<String>> products;
                    String dochoice = choice;
                    commandLine("clear");
                    System.out.println("[Type <back> to return to shopping menu.]");
                    dataconnection.open_con();
                    dataconnection.querydatabase("select p_type from store_inv natural join productandp_type natural join " + choice + " where store_id =" + store_id +"group by p_type order by p_type asc");
                    product_types = dataconnection.resultcolumnToArrayList();
                    dataconnection.close_con();
                    
                    dataconnection.open_con(); 
                    dataconnection.querydatabase("Select upc, brand_name, product_name, sale_price, p_type from  " + choice + " natural join makes natural join brand natural join store_inv where store_id = "+store_id+" order by p_type asc");
                    products = dataconnection.resultToArrayList();
                    dataconnection.close_con();
                    System.out.println();
                    int selectcount = 0;
                    for(int j = 0; j < product_types.size(); j++){
                      System.out.println(product_types.get(j) + ":");
                      System.out.format("%-12s %-20s %-30s %-10s","|selection #","|" + products.get(0).get(1), "|" + products.get(0).get(2), "|" + products.get(0).get(3));
                      System.out.println();
                      for(int i = 0; i < 76; i ++)
                        System.out.print("-");
                      System.out.println();
                      for(int i = 0; i < products.size(); i++){
                        
                        if((products.get(i).get(4)).equals(product_types.get(j))){
                          selectcount++;
                          String strselectcount = String.format("%-1d",selectcount);
                          System.out.format("%-12s %-20s %-30s %-10s", strselectcount + ".)" ,products.get(i).get(1), products.get(i).get(2), "$" + products.get(i).get(3));
                          System.out.print("\n");
                        }    
                      }
                      System.out.println();
                    }
                    
                    boolean forward = false;
                    System.out.print("Enter the product selection # to view or purchase: ");
                    choice = br1.readLine();
                    if (choice.equalsIgnoreCase("back"))
                      break;
                    
                    String intstring = "";
                    String stringint = "";
                    do{
                      
                      for(int i = 0; i < products.size(); i++)
                      {
                        intstring = String.valueOf(i);
                        stringint = String.valueOf(choice);
                        if(stringint.equals(intstring) && i != 0){
                          forward = true;
                        }
                      }
                      if(forward == false){
                        System.out.println("Invalid Entry");
                        System.out.print("Enter the product selection # to view or purchase: ");
                        choice = br1.readLine();
                        if (choice.equalsIgnoreCase("back"))
                          break;
                      }
                    }while(forward == false);
                    
                    if(choice.equalsIgnoreCase("back"))
                      break;
                    
                    int choiceint = 0;
                    if(!choice.equalsIgnoreCase("back")){
                      choiceint = Integer.valueOf(choice);
                      productSelection(dochoice, products.get(choiceint).get(0), store_id, cust_products );
                    }
                    if (!choice.equalsIgnoreCase("back"))
                      choice = dochoice;
                  }while(!choice.equalsIgnoreCase("back")); 
                }
              }
            }
            
            break;
////////////////////////////////////
///////////////// Shopping Cart ///
///////////////////////////////
          } else if (menuSelect.equalsIgnoreCase("b")) {
            commandLine("clear");
            BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in));
            
            for(int i = 0; i < cust_products.size(); i++)
            {
              for(int j = i + 1; j < cust_products.size(); j++)
              {
                if(cust_products.get(i).getupc().equals(cust_products.get(j).getupc())){
                  cust_products.get(i).addquantity(cust_products.get(j).getquantity()); 
                  cust_products.remove(j);
                }
              }
            }
            System.out.println("Shopping Cart: ");
            System.out.println("-------------- ");
            System.out.println();
            System.out.format("%-10s %-20s %-30s %-10s %-10s","Select #", "Brand","|Product Name", "|Price","|Quantity");
            System.out.println(); 
            for(int i = 0; i < 70; i++)
            {
              System.out.print("-");
            }
            System.out.println();
            
            if(cust_products.isEmpty())
            { 
              System.out.print("Cart is empty. Press enter to return to shopping menu.");
              br2.readLine();
            }else{
              int selectcount = 0;
              double balance = 0;
              for(int i = 0; i < cust_products.size(); i++)
              {  selectcount++;
                String strselectcount = String.format("%-1d",selectcount);
                System.out.format("%-10d %-20s %-30s %-10s %-10s", selectcount,cust_products.get(i).getbrand_name(), cust_products.get(i).getproduct_name(), cust_products.get(i).getsale_price(), cust_products.get(i).getquantity());
                System.out.println();
                balance  = balance + (Double.valueOf(cust_products.get(i).getsale_price())*(Double.valueOf(cust_products.get(i).getquantity())));
              }
              System.out.println("Balance: $" + balance);
              System.out.print("Would you like to remove items from the list (y|n)? ");
              String choice = br2.readLine();
              if(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"))
                do{       
                System.out.print("Please enter (y|n)");
                choice = br2.readLine();
              }while(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"));
              if(choice.equalsIgnoreCase("y")){   
                removefromcart(cust_products);
              }
            }
            
            System.out.println("Press enter to return to Shopping Menu");
            br2.readLine();                       
            
            storeCustomerMenu(store_id, cust_products, customer);
            break;
          } 
////////////////////////////////////////////
//////////////// Check Out Code ///////////
//////////////////////////////////////////
          else if (menuSelect.equalsIgnoreCase("c")) {
            
            boolean skipcartmess = false;
            while(true){
              commandLine("clear");
              BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in));
              
              for(int i = 0; i < cust_products.size(); i++)
              {
                for(int j = i + 1; j < cust_products.size(); j++)
                {
                  if(cust_products.get(i).getupc().equals(cust_products.get(j).getupc())){
                    cust_products.get(i).addquantity(cust_products.get(j).getquantity()); 
                    cust_products.remove(j);
                  }
                }
              }
              System.out.println("Shopping Cart: ");
              System.out.println("-------------- ");
              System.out.println();
              System.out.format("%-10s %-20s %-30s %-10s %-10s","Select #", "Brand","|Product Name", "|Price","|Quantity");
              System.out.println(); 
              for(int i = 0; i < 70; i++)
              {
                System.out.print("-");
              }
              System.out.println();
              
              if(cust_products.isEmpty() && skipcartmess == false)
              { 
                System.out.println("Cart is empty. Press Enter to return to Shopping Menu:");
                br2.readLine();
                storeCustomerMenu(store_id, cust_products, customer);
                break;
              }else{
                int selectcount = 0;
                double balance = 0;
                for(int i = 0; i < cust_products.size(); i++)
                {  selectcount++;
                  String strselectcount = String.format("%-1d",selectcount);
                  System.out.format("%-10d %-20s %-30s %-10s %-10s", selectcount,cust_products.get(i).getbrand_name(), cust_products.get(i).getproduct_name(), cust_products.get(i).getsale_price(), cust_products.get(i).getquantity());
                  System.out.println();
                  balance  = balance + (Double.valueOf(cust_products.get(i).getsale_price())*(Double.valueOf(cust_products.get(i).getquantity())));
                }
                
                System.out.println("Balance: $" + balance + "\n");
                System.out.print("Check Out Options: \n");
                System.out.println("a) Purchase\nb) Remove Items \nc) Return to Shopping Menu\nd) Exit");
                while (true) {
                  System.out.print("Enter Selection: ");
                  menuSelect = br.readLine();
                  if (menuSelect.length() > 1 || menuSelect.length() < 1) {
                    System.out.println("Invalid input, please type in a, b, c or d");
                  } else {
                    if (menuSelect.equalsIgnoreCase("a")) {
                      transaction(cust_products, customer);
                      skipcartmess = true;
                      break;
                      
                    } else if (menuSelect.equalsIgnoreCase("b")) {
                      System.out.println("You chose B");
                      removefromcart(cust_products);
                      break;
                    } else if (menuSelect.equalsIgnoreCase("c")) {
                      System.out.println("You chose C");
                      storeCustomerMenu(store_id, cust_products, customer);
                      break;
                    } else if (menuSelect.equalsIgnoreCase("d")){
                      System.exit(0);
                    }else {
                      System.out.println("Invalid input, please type in a, b, or c, or back");
                      
                      // break;
                      
                    }
                  }
                }
                if (menuSelect.equalsIgnoreCase("back"))
                  break; 
              }
            }     
            break;
          } else if (menuSelect.equalsIgnoreCase("d")) {
            System.out.println("You chose C"); // you can delete this 
            // put in method for c
            // put in Shopping Cart stuff
            break;
          } else if (menuSelect.equalsIgnoreCase("back")) {
            System.out.println("You chose back");
            customerMenu(); // goes back to customer menu
            break;
          } else {
            System.out.println("Invalid input, please type in a, b, c, d, or back");
            
          }
        }
      }
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
//////////////////////////////////
/////// Transacition     ////////
////////////////////////////////
  public void transaction (ArrayList<cust_product> cust_products, cust customer)
  {
    try{
      BufferedReader brtran = new BufferedReader(new InputStreamReader(System.in));
      boolean endtran = false;
      while(true){
        
        if(endtran != true){
          endtran = false;
        }
        commandLine("clear");
        System.out.println("Shopping Cart: ");
        System.out.println("-------------- ");
        System.out.println();
        System.out.format("%-10s %-20s %-30s %-10s %-10s","Select #", "Brand","|Product Name", "|Price","|Quantity");
        System.out.println(); 
        for(int i = 0; i < 80; i++)
        {
          System.out.print("-");
        }
        System.out.println();
        int selectcount = 0;
        double balance = 0;
        for(int i = 0; i < cust_products.size(); i++)
        {  selectcount++;
          String strselectcount = String.format("%-1d",selectcount);
          System.out.format("%-10d %-20s %-30s %-10s %-10s", selectcount,cust_products.get(i).getbrand_name(), cust_products.get(i).getproduct_name(), cust_products.get(i).getsale_price(), cust_products.get(i).getquantity());
          System.out.println();
          balance  = balance + (Double.valueOf(cust_products.get(i).getsale_price())*(Double.valueOf(cust_products.get(i).getquantity())));
        }
        
        System.out.println("Balance: $" + balance + "\n");
        System.out.print("Check Out\n");
        
        String choice;
        if(endtran == false){
          System.out.println("Please select a Payment Method: \na) Cash \nb) Credit");
          
        }
        
        
        if(cust_products.isEmpty()){    
          if(endtran == true)
            System.out.println("Thank you For Shopping at REI!");
          brtran.readLine();
         
          break;
        }
        while(endtran == false){
          
          System.out.print("Select payment method: ");
          choice = brtran.readLine();
          if(choice.equalsIgnoreCase("back"))
               {break;};
             
          if (choice.length() > 1 || choice.length() < 1) {
            System.out.println("Invalid input, please type in a or b");
          } else {
            if (choice.equalsIgnoreCase("a")) {
              if(cust_products.isEmpty() )
                break;
              else{
                
                DateFormat df = new SimpleDateFormat("ddMMyyyy");
                Date today = Calendar.getInstance().getTime(); 
                String trandate = df.format(today);
                
                dataconnection.open_con();
                for(int i = 0; i < cust_products.size(); i++)
                {
                  dataconnection.updatedatabase("insert into cust_trans values ("+cust_products.get(i).getstore_id() + ", " + customer.getcust_id() + ", " + cust_products.get(i).getupc() + ", " + "to_date('" + trandate + "','DDMMYYYY')"+ ", " + cust_products.get(i).getsale_price() + ", " + cust_products.get(i).getquantity()+")");
                }
                dataconnection.close_con();
                cust_products.clear();
                endtran = true;
                break;              
              }           
              // put in method for a
              // break;
            } else if (choice.equalsIgnoreCase("b")) {
              System.out.println("You chose B");

              if(customer.getonline() == false)
              customer = signup(false);
              if(cust_products.isEmpty() )
                break;
              else{
                
                DateFormat df = new SimpleDateFormat("ddMMyyyy");
                Date today = Calendar.getInstance().getTime(); 
                String trandate = df.format(today);
                
                dataconnection.open_con();
                for(int i = 0; i < cust_products.size(); i++)
                {
                  dataconnection.updatedatabase("insert into cust_trans values ("+cust_products.get(i).getstore_id() + ", " + customer.getcust_id() + ", " + cust_products.get(i).getupc() + ", " + "to_date('" + trandate + "','DDMMYYYY')"+ ", " + cust_products.get(i).getsale_price() + ", " + cust_products.get(i).getquantity()+")");
                }
                dataconnection.close_con();
                cust_products.clear();
                endtran = true;
                break;              
                 
              }
              
            } else {
              System.out.println("Invalid input, please type in a, b, or c");
              
            }
          }
        }
      break;
      }
      
    } catch (IOException e) {
      System.out.println("exception happened - here's what I know: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    } 
    
  }
  
  
  ////////////////////////////////
  ///// Selected Product ////////
  //////////////////////////////
  public void productSelection(String dept_type, String upc, String store_id, ArrayList<cust_product> cust_products) {
    try {
      commandLine("clear");
      BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
      
      List<List<String>> selecteditem;
      dataconnection.open_con();
      dataconnection.querydatabase("Select * from "+ dept_type +" natural join makes natural join brand natural join store_inv where store_id =  " + store_id +"  and upc = " + upc);
      selecteditem = dataconnection.resultToArrayList();
      dataconnection.close_con();
      
      String brand_name = selecteditem.get(1).get(1);
      String product_name = selecteditem.get(1).get(2);
      String product_type = selecteditem.get(1).get(3);
      String weight = selecteditem.get(1).get(4);
      String description = selecteditem.get(1).get(5);
      String sale_price = selecteditem.get(1).get(7);
      String quantity = "0";
      
      
      System.out.format("%-10s %-30s %-8s %-10s","Brand","|Product Name", "|Weight","|Sale Price");
      System.out.print("\n");
      for(int i = 0; i < 60; i++)
      {
        System.out.print("-");
      }
      System.out.println();
      System.out.format("%-10s %-30s %-8s %-10s",brand_name,product_name,weight,"$"+sale_price);
      System.out.println();
      System.out.println("Description: " + "");
      System.out.println("-----------");
      
      List<String> paragraph = new ArrayList<String>();
      Pattern substring = Pattern.compile(".{1,50}(?:\\s|$)", Pattern.DOTALL);
      Matcher m = substring.matcher(description);
      while (m.find()) {
        paragraph.add(m.group());
      }
      
      for (int i = 0; i < paragraph.size(); i++) {
        System.out.println(paragraph.get(i));
      }
      System.out.println();
      
      String choice;
      System.out.print("Would You like to Add This product to your cart (y|n)? ");
      choice = br1.readLine();
      if(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"))
        do{       
        System.out.print("Please enter (y|n) ");
        choice = br1.readLine();
      }while(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"));
      if(choice.equalsIgnoreCase("y")){      
        
        System.out.print("Enter how many you would like to purchase: ");
        quantity = br1.readLine();
        
        while(true){     
          if(!checkint(quantity)){
            System.out.println("Please a number greater than zero: ");
            quantity = br1.readLine();}
          else if(Integer.valueOf(quantity) <= 0){
            System.out.println("Please a number greater than zero: ");
            quantity = br1.readLine();}
          
          else
            break;
        }
        
        cust_product tocart = new cust_product(upc, brand_name, product_name, product_type, weight, description, store_id, sale_price, String.valueOf(quantity));
        cust_products.add(tocart);
      }
      
      
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  ////////////////////////////////
  ///// Remove from Cart Code ///
  //////////////////////////////
  public void removefromcart(ArrayList<cust_product> cust_products) {  
    try {
      BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in));
      while(true){
        commandLine("clear");
        
        System.out.println("Shopping Cart: ");
        System.out.println("-------------- ");
        System.out.println();
        System.out.format("%-10s %-20s %-30s %-10s %-10s","Select #", "Brand","|Product Name", "|Price","|Quantity");
        System.out.println(); 
        for(int i = 0; i < 70; i++)
        {
          System.out.print("-");
        }
        System.out.println();
        
        if(cust_products.isEmpty())
        { 
          System.out.print("Cart is empty. Press enter to return to shopping menu.");
          br2.readLine();
          break;
        }else{
          double balance = 0;
          int selectcount = 0;
          for(int i = 0; i < cust_products.size(); i++)
          {  selectcount++;
            String strselectcount = String.format("%-1d",selectcount);
            System.out.format("%-10d %-20s %-30s %-10s %-10s", selectcount,cust_products.get(i).getbrand_name(), cust_products.get(i).getproduct_name(), cust_products.get(i).getsale_price(), cust_products.get(i).getquantity());
            System.out.println();
            balance  = balance + (Double.valueOf(cust_products.get(i).getsale_price())*(Double.valueOf(cust_products.get(i).getquantity())));
          }
          System.out.println("Balance: $" + balance);
        }
        boolean forward = false;
        System.out.print("Enter the selection # remove: ");
        String choice = br2.readLine();
        if (choice.equalsIgnoreCase("back"))
          break;
        
        String intstring = "";
        String stringint = "";
        do{
          
          for(int i = 1; i <= cust_products.size(); i++)
          {
            intstring = String.valueOf(i);
            stringint = String.valueOf(choice);
            if(stringint.equals(intstring) && i != 0){
              forward = true;
            }
          }
          if(forward == false){
            System.out.println("Invalid Entry");
            System.out.print("Enter selection # to remove: ");
            choice = br2.readLine();
            if (choice.equalsIgnoreCase("back"))
              break;
          }
        }while(forward == false);
        
        if(choice.equalsIgnoreCase("back"))
          break;
        
        int choiceint = 0;
        choiceint = Integer.valueOf(choice) - 1;
        
        System.out.print("How many would you like to remove (enter all to remove all)? ");
        String quantchoice = br2.readLine();
        if(quantchoice.equalsIgnoreCase("all")){
          
          if(!choice.equalsIgnoreCase("back")){
            
            cust_products.remove(choiceint);
          }
        }else{
          while(true){     
            if(!checkint(quantchoice)){
              System.out.print("Please enter a number greater than zero: ");
              quantchoice = br2.readLine();}
            else if(Integer.valueOf(quantchoice) <= 0){
              System.out.print("Please enter a number greater than zero: ");
              quantchoice = br2.readLine();
            } 
            else
              break;
          }
          String minus = String.valueOf(0 - Integer.valueOf(quantchoice));
          String currentquantity = cust_products.get(choiceint).getquantity();
          if(Integer.valueOf(currentquantity) - Integer.valueOf(quantchoice)  >= 1){
            cust_products.get(choiceint).addquantity(minus);
          }
          else{
            cust_products.remove(choiceint);
          }
        }
      }    
    }catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }  
  }
  
  /////command line method
  public static void commandLine(String command) {
    
    try {
      
      Process p = Runtime.getRuntime().exec(command);
      BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
      BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
      while ((s = input.readLine()) != null) {
        System.out.println(s);
      }
    } catch (IOException e) {
      System.out.println("exception: ");
      e.printStackTrace();
      System.exit(-1);
      
    } catch (Exception e) {
      e.printStackTrace();
    }   
  }
  
  //returns true if number format is int or double and false otherwise
  public static boolean checkint(String s) {
    try { 
      Integer.parseInt(s);
      Double.parseDouble(s);
    } catch(NumberFormatException e) { 
      return false; 
    } 
    return true;
  }
  
  // returns true if query does not return a resul and true otherwhise.
  public  boolean checknoresult(String s)throws SQLException, IOException, java.lang.ClassNotFoundException {
    try 
    {
      List<List<String>> att;       
      dataconnection.open_con();
      dataconnection.querydatabase(s);
      att = dataconnection.resultToArrayList();
      dataconnection.close_con();
      try{

       att.get(1).get(0);
        
      }catch(IndexOutOfBoundsException e){
        return true;
        
      }
    } catch(SQLException sqle){System.out.println("Attempt failed ");}           
    return false;        
  }
  
  public String Capstring(String word)
  {
    
    word = word.toLowerCase();
    String Capletter = word.substring(0,1).toUpperCase();
    return word = Capletter + word.substring(1,word.length());
    
  }
  
  public static String uniqueid()throws SQLException, IOException, java.lang.ClassNotFoundException{
    boolean notunique = true;
    boolean unique = true;
    String id = "";
    
    while(notunique){
      Random integer1 = new Random(); 
      int int1;
      Random integer2 = new Random();
      int int2;
      Random integer3 = new Random();
      int int3;
      Random integer4 = new Random();
      int int4;
      Random integer5 = new Random();
      int int5;
      Random integer6 = new Random();
      int int6;
      
      
      int1 = (integer1.nextInt(9) + 0 );
      int2 = (integer2.nextInt(9) + 0);
      int3 = (integer3.nextInt(9) + 0);
      int4 = (integer4.nextInt(9) + 0);
      int5 = (integer5.nextInt(9) + 0);
      int6 = (integer6.nextInt(9) + 0);
      id = int1 + "" + int2 + "" + int3 + "" + int4 + "" + int5 + "" + int6;
      try{    
        DBinterface connection = new DBinterface();
        
        List<String> DBids = new ArrayList<String>();
        
        
        connection.open_con();
        connection.querydatabase("select cust_id from store_cust");
        DBids = connection.resultcolumnToArrayList();
        connection.close_con();
        int i = 0;
        while(i > DBids.size()){
          if(Integer.valueOf(DBids.get(i)) == Integer.valueOf(id)){
            unique = false;
          }
          
        }
        if(unique)
          break;
      } catch(SQLException sqle){System.out.println("Attempt failed " + sqle) ;}
      
      
    } // end of while
    return id;
  }
  
}// end of JavaRunCommand2


