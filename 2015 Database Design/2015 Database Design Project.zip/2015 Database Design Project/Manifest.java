import java.sql.*;
import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class projectinterface {
  
  public static String DBusername = "cyw214";
  public static String DBpassword = "1234!@#$";
  
  
  
  public static void main(String[] args)  throws SQLException, IOException, java.lang.ClassNotFoundException {
    try {
      
    
      
     JavaRunCommand2 jrc = new JavaRunCommand2();
     jrc.mainMenu();
      
     //storemanagerinterface smi = new storemanagerinterface();
     //smi.mainMenu();
   
    //String D = "01/02/2013";
//     
   //  System.out.println(D.substring(0,2) + "" + D.substring(2,3)  +  "" + D.substring(3,5) + D.substring(5,6) + D.substring(6,10));
      //D = D.substring(0,2) + "" + D.substring(3,5) + "" + D.substring(6,10);
  //   System.out.println(D.substring(6,10));
 //     System.out.println(Integer.valueOf(D.substring(6,10)));
//      System.out.println(D);
      
   
//              if(!D.substring(2,2).equals("/") && !D.substring(5,5).equals("/"))
//       return false;
//     else if(Integer.valueOf(D.substring(0,2)) < 10 && !D.substring(0,0).equals("0"))
//       return false;
//     else if (Integer.valueOf(D.substring(6,9)) < 2000 ||  Integer.valueOf(D.substring(6,9)) > 2015)
//       return false;
      
   
   
    } catch(Exception e){e.printStackTrace();}
  }
  
}



 